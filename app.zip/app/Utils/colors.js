export default {
    primary : '#008000',
    secondary : '#5A82FA',
    light : '#ccffcc',
    dark : '#0f4d0f',
    white : 'white',
    black : 'black',
    backgroundcolor1 : '#567FE8', //#5A82FA
    backgroundcolor2 : '#FFFFFF',
    Button1:'#002C9D', //#061cc7
    warningcolor1 : '#8d0404',
    inputfields1:'#325bd6',
    line1: '#C0C0C0',
    logocontainer : '#2e63e8',
    btn : '#002C9D',
}